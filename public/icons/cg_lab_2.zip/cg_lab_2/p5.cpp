#include <graphics.h>
#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    initwindow(800, 600, (char*)"2D Translation");

    // Coordinates for the rectangle (Top-Left and Bottom-Right)
    int x1 = 100, y1 = 100, x2 = 250, y2 = 200;
    int tx, ty;

    // 1. Draw Original Object (White)
    setcolor(WHITE);
    rectangle(x1, y1, x2, y2);
    outtextxy(x1, y1 - 20, (char*)"Original");

    // 2. Input Translation Factors
    cout << "--- 2D Translation ---" << endl;
    cout << "Enter translation vector (tx ty): ";
    cin >> tx >> ty;

    // 3. Draw Translated Object (Yellow)
    // Formula: x' = x + tx, y' = y + ty
    setcolor(YELLOW);
    rectangle(x1 + tx, y1 + ty, x2 + tx, y2 + ty);
    outtextxy(x1 + tx, y1 + ty - 20, (char*)"Translated");

    getch();
    closegraph();
    return 0;
}
