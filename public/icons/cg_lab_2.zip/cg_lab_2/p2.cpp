#include <graphics.h>
#include <conio.h>

int main() {
    initwindow(800, 600, (char*)"2D Objects");

    // ========================
    //        1. HOUSE
    // ========================
    
    // Main Body
    rectangle(50, 300, 250, 500);
    
    // Roof (Triangle)
    line(50, 300, 150, 150);
    line(150, 150, 250, 300);
    
    // Door
    rectangle(120, 400, 180, 500);
    
    // Attic Window (Circle)
    circle(150, 250, 20);

    // --- NEW: Main Body Windows ---
    rectangle(70, 330, 100, 360);   // Left Window
    rectangle(200, 330, 230, 360);  // Right Window


    // ========================
    //         2. CAR
    // ========================
    
    // Car Body (Bottom)
    rectangle(400, 350, 700, 450);
    
    // Car Top (Cabin)
    rectangle(460, 280, 640, 350);
    
    // Wheels
    circle(480, 450, 35);
    circle(620, 450, 35);

    // Labels
    outtextxy(120, 520, (char*)"House");
    outtextxy(520, 520, (char*)"Car");

    getch();
    closegraph();
    return 0;
}