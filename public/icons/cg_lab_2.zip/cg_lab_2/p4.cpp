#include <graphics.h>
#include <conio.h>

void floodFill(int x, int y, int newColor, int oldColor) {
    if (getpixel(x, y) == oldColor) {
        putpixel(x, y, newColor);
        floodFill(x + 1, y, newColor, oldColor);
        floodFill(x - 1, y, newColor, oldColor);
        floodFill(x, y + 1, newColor, oldColor);
        floodFill(x, y - 1, newColor, oldColor);
    }
}

int main() {
    initwindow(640, 480, (char*)"Flood Fill Algo");

    rectangle(50, 50, 150, 150);

    // Call fill function starting at center (100, 100)
    // New Color: 4 (Red), Old Color: 0 (Black/Background)
    floodFill(100, 100, 4, 0);

    getch();
    closegraph();
    return 0;
}