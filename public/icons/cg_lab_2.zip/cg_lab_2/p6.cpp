#include <graphics.h>
#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    initwindow(800, 600, (char*)"2D Scaling");

    // Coordinates for a Triangle
    int x1 = 100, y1 = 100;
    int x2 = 200, y2 = 100;
    int x3 = 150, y3 = 200;
    float sx, sy;

    // 1. Draw Original Object (White)
    setcolor(WHITE);
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
    outtextxy(x1, y1 - 20, (char*)"Original");

    // 2. Input Scaling Factors
    cout << "--- 2D Scaling ---" << endl;
    cout << "Enter scaling factors (sx sy): ";
    cin >> sx >> sy;

    // 3. Draw Scaled Object (Yellow)
    // Formula: x' = x * sx, y' = y * sy
    setcolor(YELLOW);
    line(x1 * sx, y1 * sy, x2 * sx, y2 * sy);
    line(x2 * sx, y2 * sy, x3 * sx, y3 * sy);
    line(x3 * sx, y3 * sy, x1 * sx, y1 * sy);
    
    // Label using the first point's new coordinates
    outtextxy(x1 * sx, (y1 * sy) - 20, (char*)"Scaled");

    getch();
    closegraph();
    return 0;
}