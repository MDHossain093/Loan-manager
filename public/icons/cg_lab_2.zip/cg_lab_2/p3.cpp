#include <graphics.h>
#include <conio.h>

void boundaryFill(int x, int y, int fColor, int bColor) {
    if(getpixel(x, y) != bColor && getpixel(x, y) != fColor) {
        putpixel(x, y, fColor);
        boundaryFill(x + 1, y, fColor, bColor);
        boundaryFill(x, y + 1, fColor, bColor);
        boundaryFill(x - 1, y, fColor, bColor);
        boundaryFill(x, y - 1, fColor, bColor);
    }
}

int main() {
    initwindow(640, 480, (char*)"Boundary Fill Algo");

    // Draw Rectangle with White boundary
    rectangle(50, 50, 100, 100);

    // Call fill function starting at center (75, 75)
    // Fill Color: 4 (Red), Boundary Color: 15 (White)
    boundaryFill(75, 75, 4, 15);

    getch();
    closegraph();
    return 0;
}