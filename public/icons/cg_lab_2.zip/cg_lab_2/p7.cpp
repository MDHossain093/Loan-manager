#include <graphics.h>
#include <iostream>
#include <math.h>
#include <conio.h>

using namespace std;

int main() {
    initwindow(800, 600, (char*)"2D Rotation");

    // Original Line Coordinates
    int x1 = 100, y1 = 100, x2 = 200, y2 = 100;
    double angle, rad;

    // 1. Draw Original Line (White)
    setcolor(WHITE);
    line(x1, y1, x2, y2);
    outtextxy(x2 + 10, y2, (char*)"Original");

    // 2. Input Rotation Angle
    cout << "--- 2D Rotation ---" << endl;
    cout << "Enter angle (degrees): ";
    cin >> angle;

    // Convert degrees to radians
    rad = angle * (3.14159 / 180.0);

    // 3. Calculate Rotated Coordinates
    // Formula: x' = x*cos(t) - y*sin(t), y' = x*sin(t) + y*cos(t)
    int nx1 = abs(x1 * cos(rad) - y1 * sin(rad));
    int ny1 = abs(x1 * sin(rad) + y1 * cos(rad));
    int nx2 = abs(x2 * cos(rad) - y2 * sin(rad));
    int ny2 = abs(x2 * sin(rad) + y2 * cos(rad));

    // 4. Draw Rotated Line (Yellow)
    setcolor(YELLOW);
    line(nx1, ny1, nx2, ny2);
    outtextxy(nx2 + 10, ny2, (char*)"Rotated");

    getch();
    closegraph();
    return 0;
}
