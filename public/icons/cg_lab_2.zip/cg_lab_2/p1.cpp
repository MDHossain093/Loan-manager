#include <graphics.h>
#include <conio.h>

int main() {
    // 1. Initialize Graphics Window
    initwindow(800, 700, (char*)"Text Formatting Demo");

    int y = 20; // Vertical cursor position tracker

    // ==========================================
    //           1. DIFFERENT FONTS
    // ==========================================
    setcolor(WHITE);
    // settextstyle(font, direction, size)
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2); 
    outtextxy(20, y, (char*)"--- DIFFERENT FONT STYLES ---");
    y += 40;

    // Default Font
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"1. Default Font");
    y += 30;

    // Triplex Font
    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"2. Triplex Font");
    y += 30;

    // Sans Serif Font
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"3. Sans Serif Font");
    y += 30;

    // Gothic Font (Old English)
    settextstyle(GOTHIC_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"4. Gothic Font");
    y += 40; 

    // Script Font
    settextstyle(SCRIPT_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"5. Script Font");
    y += 50;


    // ==========================================
    //           2. DIFFERENT COLORS
    // ==========================================
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"--- DIFFERENT COLORS ---");
    y += 40;

    // Use Triplex font for better color visibility
    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 2);

    setcolor(RED);
    outtextxy(20, y, (char*)"This text is RED");
    y += 30;

    setcolor(GREEN);
    outtextxy(20, y, (char*)"This text is GREEN");
    y += 30;

    setcolor(CYAN);
    outtextxy(20, y, (char*)"This text is CYAN");
    y += 30;

    setcolor(YELLOW);
    outtextxy(20, y, (char*)"This text is YELLOW");
    y += 50;


    // ==========================================
    //           3. DIFFERENT SIZES
    // ==========================================
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"--- DIFFERENT SIZES ---");
    y += 40;

    // Changing the 3rd parameter of settextstyle changes size
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 1);
    outtextxy(20, y, (char*)"Size 1 (Tiny)");
    y += 20;

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(20, y, (char*)"Size 2 (Normal)");
    y += 30;

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(20, y, (char*)"Size 3 (Medium)");
    y += 40;

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(20, y, (char*)"Size 4 (Large)");
    
    // Hold screen
    getch();
    closegraph();
    return 0;
}